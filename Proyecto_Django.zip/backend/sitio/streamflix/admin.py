from django.contrib import admin
from streamflix.models import *

# Register your models here.
admin.site.register(Usuario)