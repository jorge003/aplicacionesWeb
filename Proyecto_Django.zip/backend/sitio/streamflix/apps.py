from django.apps import AppConfig


class StreamflixConfig(AppConfig):
    name = 'streamflix'
